/*
    AEDS III - Trabalho Prático 2 - Busca em Grafos Sem Pesos

    Matrícula                       RA
    CAIO FERNANDO DIAS              2020.1.08.046
    MATHEUS REIS DE LIMA            2018.1.08.052
    FELIPE DE GODOI CORRÊA          2021.1.08.049
*/

#include "DFS.hpp"

int main(){
    
    // Criando um labirinto
    Labirinto lab;
    
    // Lendo a configuração do labirinto a partir de um arquivo
    LeituraConfig(&lab);

    // Imprimindo o labirinto inicial
    cout << "Labirinto inicial:" << endl;
    ImprimeLabirinto(&lab);
    cout << endl;

    // Encontrando a posição de entrada e saída no labirinto
    Posicao entrada = EncontreEntrada(&lab);
    Posicao saida = EncontreSaida(&lab);

    // Verificando se a entrada e a saída foram encontradas
    if (entrada.x == -1 || entrada.y == -1) {
        cout << "Entrada não encontrada!" << endl;
        return 1;
    }

    if (saida.x == -1 || saida.y == -1) {
        cout << "Saída não encontrada!" << endl;
        return 1;
    }

    // Inicializando a matriz de visitados
    bool visited[MAXTAM][MAXTAM] = {false};

    // Inicializando a pilha
    Pilha p;
    FPVazia(&p);

    // Executando a busca em profundidade (DFS)
    cout << "Executando DFS..." << endl;
    if (DFS(&lab, entrada.x, entrada.y, visited, &p)) {
        cout << "Saída encontrada!" << endl;
    } else {
        cout << "Saída não encontrada!" << endl;
    }
    return 0;
}

