#ifndef DFS_HPP
#define DFS_HPP

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

#define MAXTAM 100

struct Posicao{
    int x, y;
};

struct Block{
    Posicao data;
    Block *prox;
};

struct Pilha{
    Block *base;
    Block *top;
};

struct Labirinto{
    char matriz[MAXTAM][MAXTAM];
    int tam;
};

void FPVazia(Pilha *p);
void Push(Pilha *p, Posicao d);
void Pop(Pilha *p, Posicao *d);
bool PilhaVazia(Pilha *p);

void LeituraConfig(Labirinto *lab);
void ImprimeLabirinto(Labirinto *lab);

Posicao EncontreEntrada(Labirinto *lab);
Posicao EncontreSaida(Labirinto *lab);

bool DFS(Labirinto *lab, int x, int y, bool visited[][MAXTAM], Pilha *p);

#endif
