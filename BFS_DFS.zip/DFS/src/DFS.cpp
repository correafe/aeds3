#include "DFS.hpp"

void FPVazia(Pilha *p){
    p->base = new Block;
    p->top = p->base;
    p->base->prox = nullptr;
}

void Push(Pilha *p, Posicao d){
    Block *aux = new Block;
    aux->data = d;
    aux->prox = p->top;
    p->top = aux;
}

void Pop(Pilha *p, Posicao *d){
    Block *aux;
    if(p->base == p->top || p == nullptr){
        cout << "PILHA VAZIA!\n";
        return;
    }
    aux = p->top;
    p->top = aux->prox;
    *d = aux->data;
    delete aux;
}

bool PilhaVazia(Pilha *p){
    return (p->top == p->base);
}

void LeituraConfig(Labirinto *lab){
    ifstream arq("labirinto5.txt");
    if(arq.is_open()){
        string linha;
        int linhaAtual = 0;
        while (getline(arq, linha) && linhaAtual < MAXTAM) {
            for(int j = 0; j < static_cast<int>(linha.length()) && j < MAXTAM; j++){
                lab->matriz[linhaAtual][j] = linha[j];
            }
            linhaAtual++;
        }
        lab->tam = linhaAtual; // Atualizar o tamanho do labirinto
        arq.close();
    } else {
        cout << "Erro ao abrir o arquivo!" << endl;
    }
}

void ImprimeLabirinto(Labirinto *lab){
    for (int i = 0; i < lab->tam; ++i) {
        for (int j = 0; j < lab->tam; ++j) {
            cout << lab->matriz[i][j] << " ";
        }
        cout << endl;
    }
}


Posicao EncontreEntrada(Labirinto *lab){
    for (int i = 0; i < lab->tam; ++i) {
        for (int j = 0; j < lab->tam; ++j) {
            if (lab->matriz[i][j] == 'E') {
                return {i, j};
            }
        }
    }
    // Se não encontrou a entrada, retorna (-1, -1)
    return {-1, -1};
}

Posicao EncontreSaida(Labirinto *lab){
    for (int i = 0; i < lab->tam; ++i) {
        for (int j = 0; j < lab->tam; ++j) {
            if (lab->matriz[i][j] == 'S') {
                return {i, j};
            }
        }
    }
    // Se não encontrou a saída, retorna (-1, -1)
    return {-1, -1};
}

bool DFS(Labirinto *lab, int x, int y, bool visited[][MAXTAM], Pilha *p){
    static int row[] = {-1, 0, 0, 1};
    static int col[] = {0, -1, 1, 0};
    
    Push(p, {x, y});
    visited[x][y] = true;
    
    while (!PilhaVazia(p)) {
        Posicao curr;
        Pop(p, &curr);
        
        cout << "(" << curr.x << ", " << curr.y << ")" << endl; // Processa o vértice visitado
        
        if (lab->matriz[curr.x][curr.y] == 'S') {
            return true; // Chegou ao destino
        }
        
        for (int i = 0; i < 4; ++i) {
            int newRow = curr.x + row[i];
            int newCol = curr.y + col[i];
            
            if (newRow >= 0 && newRow < lab->tam && newCol >= 0 && newCol < lab->tam &&
                lab->matriz[newRow][newCol] != 'X' && !visited[newRow][newCol]) {
                Push(p, {newRow, newCol});
                visited[newRow][newCol] = true;
            }
        }
    }
    
    return false; // Não encontrou o destino
}
