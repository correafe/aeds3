#ifndef BFS_HPP
#define BFS_HPP

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

#define MAXTAM 100 // Definir o tamanho máximo do labirinto

struct ItemB {
    int val;
};

struct BlockB {
    ItemB data;
    BlockB* prox;
};

struct Fila {
    BlockB* prim;
    BlockB* ult;
};

struct Labirinto{
	int tam;
	int vet_aux[MAXTAM];
	char matriz[MAXTAM][MAXTAM];
};


void FFVazia(Fila *f);
void Enfileira(Fila *f, ItemB d);
void Desenfileira(Fila *f, ItemB *d);
bool Verifica_fila_vazia(Fila *f);

void LeituraConfig(Labirinto *lab);
void ImprimeLabirinto(Labirinto *lab);
void EncontraEntrada(Labirinto *lab, int *i, int *j);
void EncontraSaida(Labirinto *lab, int *i, int *j);
void BFS(Labirinto *lab);

#endif
