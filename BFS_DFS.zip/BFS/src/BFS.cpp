#include "BFS.hpp"

void FFVazia(Fila *f) {
    f->prim = (BlockB*) malloc (sizeof(BlockB));
    f->ult  = f->prim;
    f->prim->prox = NULL;
}

void Enfileira(Fila *f, ItemB d) {
    f->ult->prox = (BlockB*) malloc (sizeof(BlockB));
    f->ult = f->ult->prox;
    f->ult->data = d;
    f->ult->prox = NULL;
}

void Desenfileira(Fila *f, ItemB *d) {
    if(f->prim == f->ult || f == NULL || f->prim->prox == NULL) {
        cout << "Erro: Fila vazia!" << endl;
        return;
    }
    BlockB *aux = f->prim->prox;
    f->prim->prox = aux->prox;
    if (f->prim->prox == NULL) {
        f->ult = f->prim;
    }
    *d = aux->data;
    free(aux);
}

bool VerificaFilaVazia(Fila *f) {
    return (f->prim == f->ult || f == NULL || f->prim->prox == NULL);
}

void LeituraConfig(Labirinto *lab) {
    ifstream arq("labirinto5.txt");
    if (arq.is_open()) {
        string linha;
        int linhaAtual = 0;
        while (getline(arq, linha) && linhaAtual < MAXTAM) {
            for (int j = 0; j < static_cast<int>(linha.length()) && j < MAXTAM; j++){
                lab->matriz[linhaAtual][j] = linha[j];
            }
            linhaAtual++;
        }
        lab->tam = linhaAtual;
        arq.close();
    } else {
        cout << "Erro ao abrir o arquivo!" << endl;
    }
}

void ImprimeLabirinto(Labirinto *lab) {
    for (int i = 0; i < lab->tam; i++) {
        for (int j = 0; j < lab->tam; j++) {
            cout << lab->matriz[i][j] << " ";
        }
        cout << endl;
    }
}

void EncontrarEntrada(Labirinto *lab, int *i, int *j) {
    for (*i = 0; *i < lab->tam; (*i)++) {
        for (*j = 0; *j < lab->tam; (*j)++) {
            if (lab->matriz[*i][*j] == 'E') {
                return;
            }
        }
    }
}

void EncontrarSaida(Labirinto *lab, int *i, int *j) {
    for (*i = 0; *i < lab->tam; (*i)++) {
        for (*j = 0; *j < lab->tam; (*j)++) {
            if (lab->matriz[*i][*j] == 'S') {
                return;
            }
        }
    }
}

void BFS(Labirinto *lab) {
    Fila fila;
    FFVazia(&fila);

    int inicio_i, inicio_j;
    EncontrarEntrada(lab, &inicio_i, &inicio_j);

    ItemB inicio;
    inicio.val = inicio_i * MAXTAM + inicio_j;
    Enfileira(&fila, inicio);

    int direcoes[4][2] = {{-1, 0}, {0, -1}, {0, 1}, {1, 0}}; // cima, esquerda, direita, baixo

    vector<pair<int, int>> caminho;

    while (!VerificaFilaVazia(&fila)) {
        ItemB atual;
        Desenfileira(&fila, &atual);
        inicio_i = atual.val / MAXTAM;
        inicio_j = atual.val % MAXTAM;

        for (int d = 0; d < 4; d++) {
            int prox_i = inicio_i + direcoes[d][0];
            int prox_j = inicio_j + direcoes[d][1];
            
            if (prox_i >= 0 && prox_i < lab->tam && prox_j >= 0 && prox_j < lab->tam &&
                lab->matriz[prox_i][prox_j] != 'X') {
                if (lab->matriz[prox_i][prox_j] == 'S') {
                    caminho.push_back({prox_i, prox_j});
                    cout << "Saída encontrada!" << endl;
                    
                    cout << "Caminho percorrido:" << endl;
                    for (const auto& p : caminho) {
                        cout << p.first << "," << p.second << endl;
                    }
                    return;
                }
                lab->matriz[prox_i][prox_j] = 'X';
                ItemB prox;
                prox.val = prox_i * MAXTAM + prox_j;
                Enfileira(&fila, prox);
                caminho.push_back({prox_i, prox_j});
            }
        }
    }

    cout << "Saída não encontrada!" << endl;
}
