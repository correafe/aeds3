/*
    AEDS III - Trabalho Prático 2 - Busca em Grafos Sem Pesos

    Matrícula                       RA
    CAIO FERNANDO DIAS              2020.1.08.046
    MATHEUS REIS DE LIMA            2018.1.08.052
    FELIPE DE GODOI CORRÊA          2021.1.08.049
*/

#include "BFS.hpp"

int main() {
    Labirinto lab;
    LeituraConfig(&lab);

    cout << "Labirinto inicial:" << endl;
    ImprimeLabirinto(&lab);
    cout << endl;

    cout << "Executando BFS..." << endl;
    BFS(&lab);

    return 0;
}
