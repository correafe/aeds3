#include "grafo.hpp"
#include "grafo.cpp"

int main() {
    Grafo grafo;

    // Adicionando arestas ao grafo
    grafo.adicionarAresta(0, 1, 3);
    grafo.adicionarAresta(0, 5, 7);
    grafo.adicionarAresta(1, 2, 4);
    grafo.adicionarAresta(1, 3, 8);
    grafo.adicionarAresta(2, 4, 6);
    grafo.adicionarAresta(2, 5, 9);
    grafo.adicionarAresta(3, 4, 2);
    grafo.adicionarAresta(3, 6, 5);
    grafo.adicionarAresta(4, 7, 10);
    grafo.adicionarAresta(5, 8, 1);
    grafo.adicionarAresta(6, 9, 3);
    grafo.adicionarAresta(7, 8, 4);
    grafo.adicionarAresta(8, 9, 2);
    grafo.adicionarAresta(1, 10, 2);
    grafo.adicionarAresta(7, 11, 4);
    grafo.adicionarAresta(4, 12, 5);
    grafo.adicionarAresta(2, 13, 2);
    grafo.adicionarAresta(8, 14, 4);
    grafo.adicionarAresta(11, 15, 2);
    grafo.adicionarAresta(2, 16, 2);
    grafo.adicionarAresta(9, 17, 5);
    grafo.adicionarAresta(17, 18, 2);
    grafo.adicionarAresta(8, 19, 2);
    grafo.adicionarAresta(4, 20, 5);
    grafo.adicionarAresta(8, 21, 7);
    grafo.adicionarAresta(7, 22, 2);
    grafo.adicionarAresta(6, 23, 8);
    grafo.adicionarAresta(4, 24, 6);

    // Imprimindo o grafo
    grafo.imprimirGrafo();

    // Testando o algoritmo de Dijkstra
    vector<int> distancias = grafo.dijkstra(0);

    cout << "\nDistancias minimas a partir do vertice 0:\n";
    for (int i = 0; i < MAX_VERTICES; i++) {
        if (distancias[i] != numeric_limits<int>::max()) {
            cout << "Vertice " << i << ": " << distancias[i] << "\n";
        } else {
            cout << "Vertice " << i << ": Infinito\n";
        }
    }

    // Calculando e imprimindo a centralidade de closeness para cada vértice
    cout << '\n';
    for (int v = 0; v < MAX_VERTICES; ++v) {
        double closeness = grafo.closeness_centrality(v);
        cout << "Medida de centralidade de proximidade do vertice " << v << ": " << closeness << endl;
    }

    return 0;
}

/*

OBS: Como inserir os vértices do meu grafo e os pesos automaticamente

Próximos passo para desenvolver o código

Passo (Estrutura de dados para grafos) 
-> Lista de adjacência

Passo (Caminho mínimo: Dijkstra)
-> Implementado

Passo (Cálculo de métrica de centralidade)
-> Closeness

Passo (Algoritmo de desenho de grafo)
-> Impressão

*/